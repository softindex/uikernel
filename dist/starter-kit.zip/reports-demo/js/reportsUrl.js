/**
 * Copyright (с) 2015, SoftIndex LLC.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @providesModule UIKernel
 */

var reportsUrl = {
  setUrl: function (drillDowns, filters) {
    history.pushState(null, null, '/baz.')
  },

  getStateFromUrl: function () {

  }
};